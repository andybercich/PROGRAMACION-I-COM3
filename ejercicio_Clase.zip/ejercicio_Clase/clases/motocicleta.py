class Motocicleta:
    state= "Nuevo"
    motor = False
    def __init__(self, color, matricula, combustible_litros, numero_ruedas,fecha_fabricacion,velocidad_max,peso):
        self.color = color
        self.matricula = matricula
        self.combustible_litros = combustible_litros
        self.numero_ruedas =  numero_ruedas
        self.__marca= ""
        self.__modelo = ""
        self.fecha_fabricacion = fecha_fabricacion
        self.velocidad_max = velocidad_max
        self.peso = peso
        
    @property
    def marca (self):
        return self.__marca
    @property
    def modelo (self):
        return self.__modelo
    @marca.setter
    def marca(self, new_marc):
        self.__marca = new_marc
    @modelo.setter
    def modelo(self,new_model):
        self.__modelo = new_model
        
    def encender(self):
        if (self.motor == True):
            print("El motor ya esta encendido")
        else :
            print("El motor se encendió")
            self.motor = True

    def detener(self):
        if self.motor == True:
            self.motor = False
            print("El motor se apagó")
        elif self.motor == False:
            print("El motor ya está apagado")
            
    def Consultar_precio(self):
        print(f"El valor de la motocicleta {self.marca}: {self.modelo} es de {self.precio}")