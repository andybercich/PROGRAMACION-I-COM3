import sys 
sys.path.append ("C:/Users/andyb/OneDrive/Escritorio/ejercicio_Clase/clases")
from motocicleta import Motocicleta
moto_one = Motocicleta("rojo", "ab4578as", 18, 2, 2023, 350, 800)
moto_two = Motocicleta("Azul", "ab478cd", 10, 2, 2022, 300, 700)
moto_one.precio = 20000
moto_two.precio = 15000

moto_two.marca = "KTM"
moto_two.modelo = "x550"
moto_one.marca = "Royal Enfield"
moto_one.modelo = "785XS"

moto_one.encender()
moto_one.encender()
moto_one.detener()
moto_one.detener()

print(F"El precio de la motocicleta {moto_two.marca} {moto_two.modelo} es de {moto_two.precio}")

moto_two.Consultar_precio()
moto_one.Consultar_precio()



 