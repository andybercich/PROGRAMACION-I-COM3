import random
def NumerosBingo():
    lis_bingo = []
    bingo_definitive_list = []
    aux_bingo = []
    num_user = 0
    while len(lis_bingo)<25:
        num_bingo = int(input(f"Ingresa tu numero {num_user+1} del bingo: "))
        while num_bingo<0 or num_bingo>75 or num_bingo in lis_bingo:
            num_bingo = int(input(f"El número debe ser entre 1 al 75 y no debe repetirse, ingresa de nuevo el número {num_user+1}: "))
        num_user+=1
        lis_bingo.append(num_bingo)
    count = 0
    while count !=26:
        if (count%5 == 0 and count !=0):
            bingo_definitive_list.append(aux_bingo)
            aux_bingo=[]
        if count ==25:
            break
        aux_bingo.append(lis_bingo[count])
        count+=1
    return bingo_definitive_list


def Lets_Play_Bingo(card):
    verts = []
    horizontal = []
    virtual_bingo = [["0","0","0","0","0"],["0","0","0","0","0"],["0","0","0","0","0"],["0","0","0","0","0"],["0","0","0","0","0"]]
    diagonal = []
    invers =[]
    random_bingo = []
    
    for i in range(0,5):
        for x in range(0,5):
            if x == i:
                diagonal.append(card[i][x])
                
    num_invers = 4
    
    for x in range(0,5):
        invers.append(card[x][num_invers])
        num_invers-=1
        
                
    for i in range(0,5):
        aux_vert = []
        for x in range(0,5):
            aux_vert.append(card[i][x])
        verts.append(aux_vert)
        
    for i in range(0,5):
        aux_vert = []
        for x in range(0,5):
            aux_vert.append(card[x][i])
        horizontal.append(aux_vert)
        
    while  2>1:
        
        print(" \n \n\n")
        print("TU BINGO CON LOS NÚMEROS MARCADOS")
        for i in card:
            print(i,end="      ")
            print(" ")
        print("\n \n\n")
        print("NÚMEROS QUE HAN SALIDO")
        print(random_bingo)
        
        random_num = random.randint(1,75)
        while random_num in random_bingo:
            random_num = random.randint(1,75)
        
        random_bingo.append(random_num)
        
        print("EL NÚMERO QUE SALIÓ ES ", random_num)
        
        for i in range(0,5):
            x = 0
            for c in card[i]:
                if c == random_num:
                    card[i][x] = "x"
                x+=1
                
        for i in range(0,5):
            x = 0
        for c in card[i]:
            if c == random_num:
                virtual_bingo[i][x] = "x"
            x+=1
            
        coincidence_diagonal = 0
        coincidence_invers = 0
        for i in random_bingo:
            if i in invers:
                coincidence_invers+=1
            if i in diagonal:
                coincidence_diagonal +=1
        
        for i in range(0,5):
            coincidence_vertical = 0
            coincidence_horizontal = 0
            for n in verts[i]:
                if n in random_bingo:
                    coincidence_vertical +=1
                    
            for l in horizontal[i]:
                if l in random_bingo:
                    coincidence_horizontal+=1
                    
            if coincidence_vertical == 5 or coincidence_horizontal == 5:
                print(" \n \n\n")
                print("""GANASTE EL BINGOOOO, CON UNA VERTICAL U HORIZONTAL!!!!!
TU BINGO CON LOS NÚMEROS MARCADOS""")
                for i in card:
                    print(i,end="     ")
                    print(" ")
                return" "
            
        if coincidence_invers == 5 or coincidence_diagonal == 5:
            print(" \n \n\n")
            print("GANASTE EL BINGOOOO, CON UNA DIAGONAL!!!!!")
            print("TU BINGO CON LOS NÚMEROS MARCADOS")
            for i in card:
                print(i,end="     ")
                print(" ")
            break
    
