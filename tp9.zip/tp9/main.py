from clases.persona import Person
from clases.cuenta import Cuenta
from clases.triangulo import Triangulo
from clases.agenda import Agenda

#Ejercicio 1
person1 = Person()

new_name = input("Ingrese el nombre y apellido de la persona: ").title()
name_li = new_name.split()

while len(name_li)<2 or len(name_li)>3:
    new_name = input("Debe ser nombre y apellid por favor: ").title()
    name_li = new_name.split()
    
person1.name = new_name

new_age = int(input("Ingresa la edad: "))
while new_age >110 or new_age <= 0:
    
    new_age = int(input("La edad debe ser mayor que 0 y menor que 110: "))
person1.age = new_age

new_dni = int(input("Ingresa el numero de DNI: "))

while new_dni <=1000000:
    
    new_dni = int(input("El DNI debe ser mayor a 0: "))
    
person1.DNI= new_dni
person1.MostrarDatos()

if person1.MayorEdad() == True:
    print("Es mayor de edad")
else:
    print("No es mayor de edad")

#Ejercicio 2
options = """
1) Mostrar datos 
2) Retirar Dinero
3) Ingresar Dinero
4) Salir
"""
cuenta1 = Cuenta()
client = input("Ingrese el nombre y apellido de la persona: ").title()
client_li = client.split()
while len(client_li)<2:
    client = input("Debe ser nombre y apellid por favor: ").title()
    client_li = client.split()
cuenta1.Cliente = client
option2 = -1
while(option2 != 4):
    print(options)
    option2 = int(input("Ingresa la opcion: "))
    
    if option2 == 3:
        money = float(input("Ingresa el dinero que deseas ingresar: ")) 
        while money<= 0:
            money = float(input("Debe ser positivo: "))
        cuenta1.Ingresar(money)
    elif option2 == 2:
        money_reti = float(input("Ingresa que dinero deseas retirar: "))
        while money_reti <= 0:
            money_reti = float(input("Debe ser positivo: "))
        cuenta1.Retirar(money_reti)
    elif option2 == 1:
        cuenta1.MostrarCuenta()

#Ejercicio 3
side1 = float(input("Ingresa el largo del lado1 : "))
while side1<= 0:
    side1 = float(input("El valor debe ser positivo : "))
side2 = float(input("Ingresa el largo del lado2 : "))
while side2 <= 0: 
        side2 = float(input("El valor debe ser positivo : "))
side3 = float(input("Ingrese el largo del lado 3: "))
while side3 <= 0: 
        side3 = float(input("El valor debe ser positivo : "))

triangle = Triangulo(side1, side2,side3)
triangle.LadoMayor()
triangle.TypeTriangle()


#Ejercicio 4

diary1 = Agenda()
option = 1
while option != 5:
    option = int(input("""Que desea hacer con su agenda.
1) Agregar contacto
2) Ver Agenda
3) Buscar Contacto
4) Editar Contacto
5) Cerrar Agenda: """))
    while option != 1 and option!= 2 and option!= 3 and option != 4 and option != 5:
            option = int(input("""Ingrese un número válido.
1) Agregar contacto
2) Ver Agenda
3) Buscar Contacto
4) Editar Contacto
5) Cerrar Agenda: """))
            
    if option == 1:
        diary1.AddContact()
    elif option == 2:
        diary1.ShowDiary()
    elif option == 3:
        diary1.SearchContact()
    elif option == 4:
        diary1.ContactEdit()
    elif option == 5:
        print("Gracias por usarme :)")
        break
