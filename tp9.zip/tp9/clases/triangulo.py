class Triangulo: 
    def __init__(self, lado1, lado2, lado3) -> None:
        self.lado1 = lado1
        self.lado2 = lado2
        self.lado3 = lado3
    def LadoMayor(self):
        mayor = 0
        aux = ""
        if self.lado1 > mayor:
            mayor = self.lado1
            aux = "Lado 1"
            
        if self.lado2 > mayor:
            mayor = self.lado2
            aux = "Lado 2"
            
        if self.lado3 > mayor:
            mayor = self.lado3
            aux = "Lado 3"
                    
        if self.lado1 == self.lado2 and self.lado1 == self.lado3 and self.lado2 == self.lado3:
            print(f"La longitud de todos los lados es la misma: {mayor}")
        else:            
            print(f"El lado mayor es {aux}: {mayor}")
            
    def TypeTriangle(self):
        if self.lado1 == self.lado2 and self.lado1 == self.lado3 and self.lado2 == self.lado3:
            print("El triangulo es Equilatero")
        elif self.lado1 == self.lado2 or self.lado1 == self.lado3 or self.lado2 == self.lado3:
            print("El triangulo es isosceles")
        elif self.lado1 != self.lado2 and self.lado1 != self.lado3 and self.lado2 != self.lado3:
            print("El triangulo es escaleno")