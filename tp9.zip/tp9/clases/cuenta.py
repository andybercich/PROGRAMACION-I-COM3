class Cuenta: 
    
    def __init__(self) -> None:
        self.__Cliente = " "
        self.__Cantidad = 0
    
    @property
    def Cliente(self):
        return self.__Cliente
    
    @property
    def Cantidad(self):
        return self.__Cantidad
    
    @Cantidad.setter
    def Cantidad(self, cantidad):
        self.__Cantidad = cantidad
        
    @Cliente.setter
    def Cliente(self, cliente):
        self.__Cliente = cliente
        
    def MostrarCuenta(self):
        print(f"""Cliente: {self.Cliente}
Cuenta: {self.Cantidad}""")
    
    def Ingresar(self,dinero):
        self.__Cantidad += dinero
    def Retirar(self,din):
        self.__Cantidad -= din