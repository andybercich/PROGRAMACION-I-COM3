
class Person: 
    def __init__(self ):
        self.age = " "
        self.__DNI = 0
        self.__name =0
    
    @property
    def DNI(self):
        return self.__DNI
    @property
    def age(self):
        return self.__age
    @property
    def name(self):
        return self.__name
    @DNI.setter
    def DNI(self, new_DNI):
        self.__DNI = new_DNI
    @name.setter
    def name(self, new_name):
        self.__name = new_name
    @age.setter
    def age(self, new_age):
        self.__age = new_age
    def MostrarDatos(self):
        print(f"""Nombre: {self.name}
Edad: {self.age}
DNI: {self.DNI} """)
    def MayorEdad(self):
        if self.__age >=18:
            return True
        else:
            return False
