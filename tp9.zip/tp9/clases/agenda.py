class Agenda:

    def __init__(self) -> None:
        self.Diary = []

    def ShowDiary(self):
        for i in self.Diary:
            print(i, " ")
    
    def AddContact(self):
        name = input("Ingresa el nombre del contacto: ").title()
        while name == " " or name == "":
            name = input("Ingresa el nombre del contacto, no puede estar vacio: ").title()
        tel = int(input("Ingresa el número de telefono: "))
        while tel <= 0:
            tel = int(input("Por favor ingresa correctamente el número de teléfono: "))
        mail = input("Ingresa el mail del contacto: ")
        while "@gmail.com" not in mail and "@hotmail.com" not in mail:
            mail = input("Ingresa el mail del contacto, (ten en cuenta que debe finalizar con @gmail.com o @hotmail.com): ")
        aux_list = [name,tel,mail]
        self.Diary.append(aux_list)
        
        
    def SearchContact(self):

        how = int(input("Cómo desea buscar a su contacto (1 = Por nombre 2 = Nro Teléfono 3 = Mail): "))
        while how != 1 and how != 2 and how != 3:
            how = int(input("Cómo desea buscar a su contacto (1 = Por nombre 2 = Nro Teléfono 3 = Mail): "))
    
        if how == 1:
        
            name_search = input("Ingresa el nombre que deseas buscar: ").title()
            found = False
        
            for contact in self.Diary:
                name, tel, mail = contact
            
                if name == name_search:
                    print("Se encontró el nombre")
                    print(f"Nombre: {name}, Teléfono: {tel}, Email: {mail}")
                    found = True
                    break
            
            if found == False:
                print("El nombre no está en la agenda")
    
        elif how == 2:
            phone_search = input("Ingresa el número de teléfono que deseas buscar: ")
            found = False
            for contact in self.Diary:
                name, tel, mail = contact
                if str(tel) == phone_search:
                    found = True
                    print("Se encontró el número de teléfono")
                    print(f"Nombre: {name}, Teléfono: {tel}, Email: {mail}")
                    found = True
                    break
        
            if found == False:
                print("El número de teléfono no está en la agenda")
    
        elif how == 3:
            mail_search = input("Ingresa el email que deseas buscar: ")
            found = False
            for contact in self.Diary:
                name, tel, mail = contact
                if mail == mail_search:
                    print("Se encontró el email")
                    print(f"Nombre: {name}, Teléfono: {tel}, Email: {mail}")
                    found = True
                    break

            if found == False:
                print("El email no está en la agenda")
                
                
                
    
    def ContactEdit(self):
        how = int(input("Cómo desea buscar a su contacto (1 = Por nombre 2 = Nro Teléfono 3 = Mail): "))
    
        while how != 1 and how != 2 and how != 3:
            how = int(input("Cómo desea buscar a su contacto (1 = Por nombre 2 = Nro Teléfono 3 = Mail): "))
    
        search_key = None
        if how == 1:
            search_key = "nombre"
        elif how == 2:
            search_key = "número de teléfono"
        elif how == 3:
            search_key = "correo electrónico"
    
        search_value = input(f"Ingresa el {search_key} que deseas buscar para editar el contacto: ").title()
    
        found = False
        for contact in self.Diary:
            name, tel, mail = contact
            if (how == 1 and name == search_value) or (how == 2 and str(tel) == search_value) or (how == 3 and mail == search_value):
                print(f"Se encontró el {search_key}")
                print(f"Nombre: {name}, Teléfono: {tel}, Email: {mail}")
            
                edit_key = int(input("Qué desea editar (1 = Nombre 2 = Celular 3 = Mail): "))
                while edit_key not in [1, 2, 3]:
                    edit_key = int(input("Qué desea editar (1 = Nombre 2 = Celular 3 = Mail): "))
            
                if edit_key == 1:
                    name_repla = input("Ingrese el nuevo nombre: ").title()
                    while name_repla == " " or name_repla == "":
                        name_repla = input("Ingresa el nombre del contacto, no puede estar vacío: ").title()
                    contact[0] = name_repla
                    print("Se cambió el nombre")
                elif edit_key == 2:
                    tel_repla = int(input("Ingrese el nuevo número de teléfono: "))
                    while tel_repla <= 0:
                        tel_repla = int(input("Ingrese el nuevo número de teléfono: "))
                    contact[1] = tel_repla
                    print("Se cambió el número de teléfono")
                elif edit_key == 3:
                    mail_rep = input("Ingresa el nuevo correo del contacto: ")
                    while "@gmail.com" not in mail_rep and "@hotmail.com" not in mail_rep:
                        mail_rep = input("Ingresa el nuevo correo del contacto, (debe finalizar con @gmail.com o @hotmail.com): ")
                    contact[2] = mail_rep
                    print("Se cambió el correo")
                found = True
                break

        if not found:
            print(f"El {search_key} no está en la agenda")

        