import pytest
from funciones_8_11 import *

#Test Ejercicio 8
@pytest.mark.parametrize("a,res",[
    (5,"El área es: 78 y el perimetro 31."),
])
def test_funcion8(a,res):
    assert funcion8(a)==res
    
#Test Ejercicio 9

@pytest.mark.parametrize("a, b,c,d, res",[
    ("usuario1","asdasd",5, 10,True),
    ("usuario","asdasd",5, 10,False),
    ("usuario1","asdasd",2, 2,"Se agotaron el número de intentos"),
])
def test_login(a,b ,c,d,res):
    assert login(a,b,c,d)==res


#Test Ejercicio 10

@pytest.mark.parametrize("a, res",[
    ({10:10,50:5,100:8},148.5),
    ({500:50,125:8,1550:2}, 1884)
])
def test_funcion10(a, res):
    assert funcion10(a)==res

    
#Test Ejercicio 11


@pytest.mark.parametrize("a,b ,res",[
    (["Hola","Capo"], funcion11_upper, ["HOLA","CAPO"]),
    (["QUE", "BUENO QUE ESTÁ","PYTEST"], funcion11_lower, ["que","bueno que está","pytest"])
])
def test_funcion11_2(a,b, res):
    assert funcion11_2(a,b)==res

