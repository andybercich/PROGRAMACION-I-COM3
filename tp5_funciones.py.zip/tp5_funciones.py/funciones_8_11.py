import math
def funcion8(a):
    area = int(math.pi * (a ** 2))
    perimeter = int(2 * math.pi * a)
    return (f"El área es: {area} y el perimetro {perimeter}.")

def login(name,password,tryes,maxtryes):
    if tryes != maxtryes:
        if name == "usuario1" and password == "asdasd":
            return True
        else:
            return False
    else:
        return"Se agotaron el número de intentos"


def funcion10(diccionary):
    pryce_of_things = list(diccionary.keys())
    off = list(diccionary.values())
    a = 0
    total = 0
    while a< len(pryce_of_things):
        total =total + pryce_of_things[a] -(pryce_of_things[a]*(off[a]/100))
        a+=1
    return total


def funcion11_2(list,funtion):
    aux=0
    list_return = []
    while aux < len(list):
        list[aux] = funtion(list[aux])
        list_return . append(list[aux])
        aux+=1
        
    return (list_return)
def funcion11_lower(b):
    return (b.lower())
def funcion11_title(c):
    return(c.title())
def funcion11_upper(a):
        return(a.upper())

