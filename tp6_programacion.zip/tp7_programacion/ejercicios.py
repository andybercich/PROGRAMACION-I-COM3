from funciones import *

#Ejercicio 1
list_num =  lista_numeros()
print(list_num)

#Ejercicio 2
num = int(input("Ingrese un numero que desee borrar de la lista: "))
print(borrar_num(num, list_num)) 

#Ejercicio 3
print("Se mostrará la suma de todos los elementos")
print(sumar_elementos(list_num))

#Ejercicio 4
num2 = int(input("Ingrese un número entero: "))
print("Se mostraran los números de la lista creada, cuando sean menores que: ", num2)
for elements in list_num:
    if elements<num2: 
        print(elements, end= ",")
print(" ")

#Ejercicio 5
print("Se mostrarán cuantas veces aparecen los números de la lista: ")
print(concurrencia_num(list_num))

#Ejercicio 6
print(nombres_colegio())

#Ejercicio 7
print(concurrencia_caracter())

#Ejercicio 8
print(resultado_final(equipos_resultado()))

#Ejercicio 9
print(juego_memo(make_memo()))

#Ejercicio 10
matriz = [[4,5,8,12],[4,7,9,14], [8,7,5,17], [15,3,2,25]]
print(matriz_inDiagonal(matriz))

#Ejercicio 11
print(cual_divisa())

#Ejercicio 12
print(datos_usuario())

#Ejercicio 13
print(verduleria())

