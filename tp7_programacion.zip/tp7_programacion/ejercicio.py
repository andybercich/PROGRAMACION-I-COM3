from funciones_oyb import *
import random
random_list = []
n = 0
while n<10:
    random_list.append(random.randint(0,100))
    n+=1
    
#Ejercicio 1
list_numbers =[]
number = int(input("Ingrese un número entero (ingrese 0 para terminar): "))
while number !=0:
    list_numbers.append(number)
    number = int(input("Ingrese un número entero (ingrese 0 para terminar): "))
    
print(Bubble_Sort(list_numbers))
decendt_numbers = Bubble_Sort(list_numbers)
m= 0
while m != -(len(decendt_numbers)):
    m-=1
    print(decendt_numbers[m] , end= " ")
print(" ")
#Ejercicio 2
word_list = []
word = input("Ingrese una palabra (sin espacios, y para terminar ingrese x): ").title()
while word!= "X":
    if len(word.split(" ")) == 1:
        word_list.append(word)
    else:
        print("La palabra ingresada tiene un espacio")
    word = input("Ingrese una palabra (sin espacios, y para terminar ingrese x): ").title()
print(Selection_Sort(word_list))

#Ejercicio 3
# Lista de diccionarios con información sobre libros
list_books = [{"Titulo": "El señor de los anillos", "Autor": "Tolkien", "Fecha": 1954},
              {"Titulo": "Ellos Vinieron", "Autor": "George Orwell", "Fecha": 1949},
              {"Titulo": "El Relato de un Naufrago", "Autor": "García Márquez", "Fecha": 1967},
              {"Titulo": "Harry Potter", "Autor": "La Que Hizo Harry Potter", "Fecha": 1997}]

option = input("""Titulo = Orden alfabético por nombre del libro
Fecha = Año de publicación
Autor = Orden alfabético por el nombre de autor
Ingrese como desea ordenar el diccionario:"""). title()
while option != "Titulo" and option != "Autor" and option!="Fecha":
    print("Opción inválida")
    option = input("""Titulo = Orden alfabético por nombre del libro
Fecha = Año de publicación
Autor = Orden alfabético por el nombre de autor
Ingrese como desea ordenar el diccionario:"""). title()
print(bubble_sort_books(list_books, option))

#Ejercicio 4
list_chain = []
chain = input("Ingrese palabras (ingresa x para terminar): ").title()
while chain!= "X":
    list_chain.append(chain)
    chain = input("Ingrese palabras (ingresa x para terminar): ").title()
print(Insert_Sort_long(list_chain))

#Ejercicio 6
print(random_list)
print(counting_sort(random_list))

#Ejercicio 7
words_number_list = ["wafesgd",4,"ertyhbg",9.54,"manzanas","cortina",15,"lapiceras",14,"cargador",13,11]
print(insert_words_numbers(words_number_list))

#Ejercicio 8
print(Merge_Sort(random_list))


