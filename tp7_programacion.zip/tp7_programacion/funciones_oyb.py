#Bubble Sort
def Bubble_Sort(listt):
    for i in range(len(listt)):
        for j in range(0,len(listt)-i-1):
            if listt[j] > listt[j+1]:
                listt[j], listt[j+1] = listt[j+1], listt[j]
    return listt

#Ordenamiento para diccionario
def bubble_sort_books(libros, campo):
    n = len(libros)
    for i in range(n - 1):
        for j in range(0, n - i - 1):
            if libros[j][campo] > libros[j + 1][campo]:
                libros[j], libros[j + 1] = libros[j + 1], libros[j]
    for libro in libros:
        print(libro)

#Ordenamiento Para longitud de cadenas
def Insert_Sort_long(listt):
    for i in range(len(listt)):
        aux = listt[i]
        j = i - 1
        while ((j >= 0) and (len(aux) < len(listt[j]))):
            listt[j + 1] = listt[j]
            j-=1            
        listt[j + 1] = aux
    return listt
        
#Selection Sort
def Selection_Sort(listt):
    for i in range(len(listt)-1):
        minor=listt[i]
        pos=i
        for j in range(i+1,len(listt)):
            if listt[j]<minor:
                minor=listt[j]
                pos=j
        if pos!=i:
            tmp=listt[i]
            listt[i]=listt[pos]
            listt[pos]=tmp
    return listt

#Insert Sort
def Insert_Sort(listt):
    for i in range(len(listt)):
        aux = listt[i]
        j = i - 1
        while ((j >= 0) and (aux < listt[j])):
            listt[j + 1] = listt[j]
            j-=1            
        listt[j + 1] = aux
    return listt

#Merge Sort
def Merge_Sort(listt):
    if len(listt) > 1:
        mid = len(listt) // 2
        left_half = listt[:mid]
        right_half = listt[mid:]

        Merge_Sort(left_half)
        Merge_Sort(right_half)

        i = j = k = 0

        while i < len(left_half) and j < len(right_half):
            if left_half[i] < right_half[j]:
                listt[k] = left_half[i]
                i += 1
            else:
                listt[k] = right_half[j]
                j += 1
            k += 1

        while i < len(left_half):
            listt[k] = left_half[i]
            i += 1
            k += 1

        while j < len(right_half):
            listt[k] = right_half[j]
            j += 1
            k += 1
    return listt

#Busqueda Lineal
def Linear_Search(listt):
    condition=False
    element=int(input("Ingrese el numero que quiere encontar: "))
    for i in listt:
        if i == element:
            condition=True

    if condition==True:
        print(f"El numero {element} se encontro en la lista")
    else:
        print(f"El numero {element} no se encontro en la lista")
        
#Busqueda Binaria
def Binary_Search(listt):
    left=0
    right=len(listt) - 1
    condition=False
    element=int(input("Ingrese el numero que quiere encontar: "))
    while left <= right:
        mid = (left + right) // 2  

        if listt[mid] == element:
            condition=True
            break  
        elif listt[mid] < element:
            left = mid + 1  
        else:
            right = mid - 1 

    if condition==True:
        print(f"El numero {element} se encontro en la lista")
    else:
        print(f"El numero {element} no se encontro en la lista")


#Ordenamiento por conteo
def counting_sort(arr):
    min_val = min(arr)
    max_val = max(arr)
    count = [0] * (max_val - min_val + 1)
    sorted_arr = []
        
    for num in arr:
        count[num - min_val] += 1

    for i in range(len(count)):
        for j in range(count[i]):
            sorted_arr.append(i + min_val)
            
    return sorted_arr

def insert_words_numbers(li):
    li_num =[]
    list_w =[]
    for i in li:
        if type(i) == int or type(i) == float:
            li_num.append(i)
        elif type(i) == str:
            list_w.append(i)
    return f"""Los números ordenados: {Insert_Sort(li_num)}
Las palabras ordenadas: {Insert_Sort(list_w)}"""
